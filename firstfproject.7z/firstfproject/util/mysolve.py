#!/usr/bin/python
# -*- coding: UTF-8 -*-


class mysolve:
    empCount = 0

    def __init__(self, name, salary):
        self.name = name
        self.salary = salary
        mysolve.empCount += 1

    def displayCount(self):
        print("Total Employee %d" % mysolve.empCount)

    def displayEmployee(self):
        print("Name : ", self.name, ", Salary: ", self.salary)

    def get_input(self):
        print(321)

    def get_name(self):
        print(321)

    def get_file(self):
        print(321)

    def get_excel(self):
        print(321)

    def set_excel(self):
        print(321)

    def test(self):
        print("self参数：", self)


if __name__ == '__main__':
    print('作为主程序运行')
    emp1 = mysolve("Zara", 2000)
    mysolve.get_file(emp1)
    mysolve.get_name(emp1)
    mysolve.set_excel(emp1)
    mysolve.get_excel(emp1)
    mysolve.get_input(emp1)
else:
    print('package_runoob 初始化')
