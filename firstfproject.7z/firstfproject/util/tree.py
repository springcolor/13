# coding:utf-8

import os


def list_files(startpath):
    toppath = startpath.split('\\')[-1]
    for root, dirs, files in os.walk(startpath):
        level = root.replace(startpath, '').count(os.sep)
        dir_indent = "|   " * (level - 1) + "|-- "
        file_indent = "|   " * level + "|-- "
        if not level:
            print('.'+toppath)
        else:
            print('{}{}'.format(dir_indent, os.path.basename(root)))
        for f in files:
            print('{}{}'.format(file_indent, f))


path = r"C:\Users\Admin\Desktop\myprivatetest"
list_files(path)
