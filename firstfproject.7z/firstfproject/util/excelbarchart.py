# !/usr/bin/env python
# -*- coding: utf-8 -*

from openpyxl import Workbook
import openpyxl
import time
from openpyxl.chart import (
    Reference,
    Series,
    BarChart
)

path = r"C:\Users\Admin\Desktop\sample.xlsx"

book = Workbook()
sheet = book.active

sheet['A2'] = 43

now = time.strftime("%x")
sheet['A3'] = now

sheet['A1'] = 1
sheet.row_dimensions[1].height = 50
sheet.column_dimensions['B'].width = 50
sheet.cell(row=2, column=2).value = 2

# rows = (
#     (88, 46, 57),
#     (89, 38, 12),
#     (23, 59, 78),
#     (56, 21, 98),
#     (24, 18, 43),
#     (34, 15, 67)
# )
#
# for row in rows:
#     sheet.append(row)

book.save(path)

book = openpyxl.load_workbook(path)
sheet = book.active

for row in sheet.iter_rows(min_row=1, min_col=1, max_row=6, max_col=3):
    for cell in row:
        print(cell.value, end=" ")
    print()
if sheet['B1'].value is not None:
    print("success")
else:
    print("fail")


book = Workbook()
sheet = book.active

rows = [
    ("USA", 46),
    ("China", 38),
    ("UK", 29),
    ("Russia", 22),
    ("South Korea", 13),
    ("Germany", 11)
]

for row in rows:
    sheet.append(row)

data = Reference(sheet, min_col=2, min_row=1, max_col=2, max_row=6)
categs = Reference(sheet, min_col=1, min_row=1, max_row=6)

chart = BarChart()
chart.add_data(data=data)
chart.set_categories(categs)

chart.legend = None
chart.y_axis.majorGridlines = None
chart.varyColors = True
chart.title = "Olympic Gold medals in London"

sheet.add_chart(chart, "A8")

book.save(path)

