# 导入包和模块
import matplotlib.pyplot as plt

# 储存温度和日期
datas = {
    '1': [22, 25, 19, 18, 25, 27, 20],
    '2': ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
}
# 绘制出图形，大小是 (15,15)
plt.figure(figsize=(15, 15))
# 绘制出图形    x轴     y轴
plt.plot(datas['2'], datas['1'])
# 设置x和y轴的文字颜色
plt.xticks(size=10, color='red')
plt.yticks(size=10, color='blue')
# 设置x轴和y轴的标签
plt.xlabel('Days', size=12, color='black')
plt.ylabel('Temperature', size=12, color='black')
# 设置标题
plt.title('Future Weather Chart Temperature Trend', size=20, color='black')
# 使用风格 bmh
plt.style.use('bmh')
# 绘制出统计图
plt.show()
