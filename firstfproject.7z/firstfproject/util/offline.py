# !/usr/bin/env python3
# -*- coding: utf-8 -*-
import datetime
import os
import shutil


def new_file(testdir, target_path):
    # 列出目录下所有的文件
    print(testdir)
    lists = os.listdir(testdir)
    print(lists)
    newlist = []
    for list in lists:
        l = testdir+list
        # print(l+'\n')
        if(os.path.isdir(l)):
            print(list)
            newlist.append(list)
            print(newlist)
        else:
            pass
    print(".......................")
    # for root, dirs, files in os.walk(testdir):
    #     list2 = dirs
    #     print(list2)
    # print(".......................")
    # 对文件修改时间进行升序排列
    newlist.sort(key=lambda fn: os.path.getmtime(testdir + '\\' + fn))
    # 获取最新修改时间的文件
    filetime = datetime.datetime.fromtimestamp(os.path.getmtime(testdir + newlist[-1]))
    # 获取文件所在目录
    filepath = os.path.join(testdir, newlist[-1])
    print("最新修改的文件(夹)：" + newlist[-1])
    print("时间：" + filetime.strftime('%Y-%m-%d %H-%M-%S'))
    target_path = target_path + newlist[-1]
    # print("\033[31;0m%s" % "输出红色字符")
    print("\033[31m要打印的文字\033[0m")
    print("\033[0;31m您输入的帐号或密码错误！\033[0m")
    print("\033[0;31m%s\033[0m" % "输出红色字符")
    print("\033[31m%s\033[0m" % target_path)
    # print("\033[31m%s" % "输出红色字符")
    if (os.path.exists(target_path)):
        print("拷贝已经存在")
    else:
        shutil.copytree(filepath, target_path)
    return filepath


if __name__ == '__main__':
    testdir = r'C:\\Users\\Admin\\Desktop\\wosi\\'
    target_path = r'C:\\Users\\Admin\\Desktop\\wosi2\\'
    # 返回最新文件或文件夹名：
    print(new_file(testdir, target_path))
    print("******************")
    cmd = 'ipconfig'
    # os.system('@chcp 65001')
    # os.system('@chcp 936')
    r = os.system(cmd)
    # r = r.decode("GBK")
    # print(type(r))

