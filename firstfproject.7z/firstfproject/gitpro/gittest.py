from git import Repo
# 创建版本库对象
from gitdb.db import git

repo = git.Repo(r'E:\Notes')
