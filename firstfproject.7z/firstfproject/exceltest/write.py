# def write_tx_name(rootdir):
#     lines = []
#     with open(rootdir, 'w') as file_to_write:
#         file_to_write.write("Add a word\n")
#         # lines.append(line)
#         # print("添加完成w")
#         lines.append("添加完成w")
#     with open(rootdir, 'a') as file_object:
#         file_object.write("lalala\n")
#         file_object.write("hahaha\n")
#         # print("添加完成a")
#         lines.append("添加完成a")
#     return lines
#
#
# def sys_out(list):
#     for lines in lineslist:  # 第二个实例
#         print(lines)


def changetext(a, b):
    poems = r'C:\Users\Admin\Desktop\c.txt'
    poems1 = r'C:\Users\Admin\Desktop\c.txt'
    with open(poems, 'r', encoding='utf-8') as f:
        lines = []  # 创建了一个空列表，里面没有元素
        for line in f.readlines():
            if line != '\n':
                lines.append(line)
        f.close()
    with open(poems, 'w', encoding='utf-8') as f:
        for line in lines:
            if a in line:
                line = b
                f.write('%s\n' % line)
            else:
                f.write('%s' % line)


if __name__ == '__main__':
    # resultpath = r'C:\Users\Admin\Desktop\c.txt'
    # # resultpath = r'C:\Users\Admin\Desktop\a\f1\f2\f33\xlsx.py'
    # lineslist = write_tx_name(resultpath)
    # sys_out(lineslist)

    changetext('4', 'cow')

    # poems = r'C:\Users\Admin\Desktop\c.txt'
    # poems1 = r'C:\Users\Admin\Desktop\c.txt'
    # with open(poems, 'r', encoding='utf-8') as p, open(poems1, 'w', encoding='utf-8')as q:
    #     number = 0
    #     for i in p:  # 循环打印poems的内容
    #         number += 1
    #         if number == 2:
    #             i = '111222\n'  # 当读到第二行的时候，替换第二行的内容为111222
    #         q.write(i)  # 把在poems中读取的内容写在poems1中

