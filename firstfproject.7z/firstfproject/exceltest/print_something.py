# 可以根据自己的需求，把常用的封装起来，用的时候直接调用就可以了
# import matplotlib.font_manager as fm

# for font in fm.fontManager.ttflist:
#   print(font.name)

# plt.rcParams['font.family'] =  'SimHei'

# 显示方式 	效果 	前景色 	背景色 	颜色描述
# 0 	终端默认设置 	30 	40 	黑色
# 1 	高亮显示 	31 	41 	红色
# 4 	使用下划线 	32 	42 	绿色
# 5 	闪烁 	33 	43 	黄色
# 7 	反白显示 	34 	44 	蓝色
# 8 	不可见 	35 	45 	紫红色
# 22 	非高亮显示 	36 	46 	青蓝色
# 24 	去下划线 	37 	47 	白色
# 25 	去闪烁
# 27 	非反白显示
# 28 	可见


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    WARNING1 = '\033[1;31m'
    WARNING2 = '\033[33m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


print('This is a \033[1;35m test \033[0m!')
print('This is a \033[1;32;43m test \033[0m!')
print('\033[1;33;44mThis is a test !\033[0m')

print(bcolors.HEADER + "警告的颜色字体?" + bcolors.ENDC)
print(bcolors.WARNING1 + "警告的颜色字体?" + bcolors.ENDC)
print(bcolors.WARNING2 + "警告的颜色字体?" + bcolors.ENDC)

print('\033[0;36m' + "警告的颜色字体?" + '\033[0m')
print('\033[0;95m' + "警告的颜色字体?" + '\033[0m')
print('\033[0;35m' + "警告的颜色字体?" + '\033[0m')

file = 'C:\\Users\\Admin\\Desktop\\a\\f1\\f2\\f3\\f4\\p5.py'
str = "C:\\Users\\Admin\\Desktop\\a\\f1\\f2\\f3\\f4\\p5.py"
# if file.strip(str):
if file == str:
    print('TRUE')
else:
    print('FALSE')
