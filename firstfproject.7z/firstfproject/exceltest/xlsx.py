import xlrd
from xlutils.copy import copy

tem_excel = xlrd.open_workbook('C:/Users/Admin/Desktop/a.xlsx')
new_excel = copy(tem_excel)
# table = xlsx.sheet_by_index(0)
# a = table.cell_value(0, 0)
# b = table.cell_value(0, 1)
# print(a)
# print(b)
# for n in range(10, table.nrows):
#     print(table.cell(n, 0).value)
#     print(table.cell(n, 1).value)
new_sheet = new_excel.get_sheet(0)
# table1 = xlsx.sheet_by_index(0)
new_sheet.write(0, 0, 'wo')
new_sheet.write(2, 2, 'wo')
new_excel.save('C:/Users/Admin/Desktop/b.xlsx')