# print('hello world')
# a = 1
# a_list = ['a', 'b', 1.3, 2, a, ['x', 'y', ['z']], ('m', 'n')]
# print(a_list)
# print(a_list[0])
# print(a_list[0:4])
# a_list.append(3)
# a_list.append(3)
# print(a_list)
# a_list.remove(3)
# print(a_list)
# a = 1
# if a == 0:
#     print("a=0")
# else:
#     print('a=1')
# a_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# # for i in a_list:
# for i in range(1, 10):
#     for j in range(1, 10):
#         print(i, j, j*i)
#         print('@@@@@@@@@@')
# a = '11'
# b = 1
# print(type(str(b)))
# print(type(int(a)))
# d = ['a', 'b', 'c', 'd']
# e = 3.14159926535
# print(type(d))
# f = input("please input:")
# # print(round(e, 4))
# print(f)


# def function(a, b, c):
#     d = a+b+c
#     print(d)
#
#
# function(3, 4, 5)
