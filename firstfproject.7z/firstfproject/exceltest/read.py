def read_tx_name(rootdir):
    lines = []
    with open(rootdir, 'r') as file_to_read:
        while True:
            line = file_to_read.readline()
            if not line:
                break
            line = line.strip('\n')
            lines.append(line)
    return lines


def sys_out(list):
    for lines in lineslist:  # 第二个实例
        print(lines)


if __name__ == '__main__':
    resultpath = r'C:\Users\Admin\Desktop\c.txt'
    # resultpath = r'C:\Users\Admin\Desktop\a\f1\f2\f33\xlsx.py'
    lineslist = read_tx_name(resultpath)
    sys_out(lineslist)
